import { Box, Typography } from '@mui/material';

const ProfileRoute = () => {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Typography variant="h6" fontWeight="600">
        پروفایل من
      </Typography>
      <Typography sx={{ color: 'text.secondary' }}>
        اطلاعات پروفایل شما در این بخش نمایش داده می‌شود. می‌توانید جزئیات
        تکمیلی را اینجا اضافه کنید.
      </Typography>
    </Box>
  );
};

export default ProfileRoute;
