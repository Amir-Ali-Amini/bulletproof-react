declare module 'stylis';
